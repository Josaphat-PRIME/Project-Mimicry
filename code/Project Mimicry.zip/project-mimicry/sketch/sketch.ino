
#include <HCSR04.h>
#include <SCServo.h>
#include <Arduino_RouterBridge.h>


SMS_STS st;





unsigned long dernierOrdre = 0;

// Watchdog timeout in milliseconds
unsigned long watchdogTimeout = 400;

int echoPins[3] = {3, 4, 5};
HCSR04 hc(2, echoPins, 3);

#define FL 1  // Front Left motor
#define RL 2  // Rear Left motor
#define FR 3  // Front Right motor
#define RR 4  // Rear Right motor


void setMotorSpeed(int16_t fl, int16_t rl, int16_t fr, int16_t rr) {
  uint8_t ids[4] = { FL, RL, FR, RR };
  int16_t speeds[4] = { fl, rl, fr, rr };
  uint16_t acc[4] = { 100, 100, 100, 100 };

  for (int i = 0; i < 4; i++) {
    st.WriteSpe(ids[i], speeds[i], acc[i]);
  }
}


void moveForward(int speed) {
  setMotorSpeed(-speed, -speed, speed, speed);
  dernierOrdre = millis();
}


void moveBackward(int speed) {
  setMotorSpeed(speed, speed, -speed, -speed);
  dernierOrdre = millis();
}


void turnLeft(int speed) {
  setMotorSpeed(speed, speed, speed, speed);
  dernierOrdre = millis();
}


void turnRight(int speed) {
  setMotorSpeed(-speed, -speed, -speed, -speed);
  dernierOrdre = millis();
}


void stopMotors() {
  setMotorSpeed(0, 0, 0, 0);
}


// ============================================================
// WATCHDOG CONFIGURATION
// ============================================================

// mode 0 = Manual       → watchdog disabled
// mode 1 = Dataset      → watchdog 400 ms
// mode 2 = Autonomous   → watchdog 600 ms

void setControlMode(int mode) {

  switch (mode) {

    case 0:
      // Manual mode
      watchdogTimeout = 0;
      break;

    case 1:
      // Dataset collection mode
      watchdogTimeout = 400;
      break;

    case 2:
      // Autonomous KNN mode
      watchdogTimeout = 600;
      break;

    default:
      // Safety fallback
      watchdogTimeout = 400;
      break;
  }

  // Reset the watchdog timer when changing mode
  dernierOrdre = millis();
}


// ============================================================
// ULTRASONIC SENSORS
// ============================================================

String Distance() {

  int dist[3]{0, 0, 0};

  for (int i = 0; i < 3; i++) {
    dist[i] = hc.dist(i);
    delay(10);
  }

  String json = "[";

  for (int i = 0; i < 3; i++) {
    json += String(dist[i]);

    if (i < 2) {
      json += ", ";
    }
  }

  json += "]";

  return json;
}


// ============================================================
// SETUP
// ============================================================

void setup() {

  Bridge.begin();

  // Functions accessible from Python
  Bridge.provide_safe("distance", Distance);
  Bridge.provide("moveForward", moveForward);
  Bridge.provide("moveBackward", moveBackward);
  Bridge.provide("turnLeft", turnLeft);
  Bridge.provide("turnRight", turnRight);
  Bridge.provide("stopMotors", stopMotors);

  // Control mode function
  Bridge.provide("setControlMode", setControlMode);

  Serial1.begin(1000000);
  st.pSerial = &Serial1;

  st.WheelMode(FL);
  st.WheelMode(FR);
  st.WheelMode(RL);
  st.WheelMode(RR);

  stopMotors();
  
  // Start in manual mode
  setControlMode(0);
}


// ============================================================
// MAIN LOOP
// ============================================================

void loop() {

  Bridge.update();

  // Watchdog is disabled when watchdogTimeout == 0
  if (
    watchdogTimeout > 0 &&
    millis() - dernierOrdre > watchdogTimeout
  ) {

    stopMotors();

    // Prevent continuous STOP commands
    dernierOrdre = millis();
  }
}