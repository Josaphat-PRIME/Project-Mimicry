# 🧑‍🧒 KNN-4WD

This app is used for collect data from 3 ultrasonic sensor and use it later for trainning a AI model based on KNN algorithm


## Common issues with arduino library

after installing the STS_Servos library, and triying to use it, an error like this sould occur

