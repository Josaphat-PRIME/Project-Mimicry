import streamlit as st
import pandas as pd
import os
import json
from datetime import datetime

import plotly.express as px

from sklearn.neighbors import KNeighborsClassifier
from arduino.app_utils import Bridge, App


# ============================================================
# CONFIGURATION
# ============================================================

DATA_DIR = "datasets"
os.makedirs(DATA_DIR, exist_ok=True)

st.set_page_config(
    page_title="KNN Autonomous Robot",
    page_icon="🤖",
    layout="centered",
    initial_sidebar_state="collapsed",
)


# ============================================================
# ROBOT CONTROL MODES
# ============================================================

MANUAL_MODE = 0
DATASET_MODE = 1
AUTONOMOUS_MODE = 2


# Watchdog values are managed by the Arduino.
WATCHDOG_VALUES = {
    MANUAL_MODE: None,
    DATASET_MODE: 400,
    AUTONOMOUS_MODE: 400,
}


# ============================================================
# MOBILE-FRIENDLY STYLE
# ============================================================

st.markdown(
    """
    <style>

    .block-container {
        max-width: 900px;
        padding-top: 1rem;
        padding-left: 0.8rem;
        padding-right: 0.8rem;
    }

    h1 {
        text-align: center;
        font-size: 2rem !important;
        margin-bottom: 0.2rem;
    }

    h2 {
        font-size: 1.4rem !important;
    }

    h3 {
        font-size: 1.15rem !important;
    }

    /* Large touch-friendly buttons */
    .stButton > button {
        min-height: 72px;
        border-radius: 18px;
        font-size: 1.9rem !important;
        font-weight: 600;
        width: 100%;
        touch-action: manipulation;
    }

    /* Start/stop buttons */
    .stButton > button[kind="primary"] {
        min-height: 58px;
        font-size: 1.05rem !important;
    }

    /* Radio buttons */
    div[role="radiogroup"] {
        gap: 0.4rem;
    }

    /* Metrics */
    [data-testid="stMetric"] {
        border-radius: 14px;
        padding: 0.4rem;
    }

    @media (max-width: 640px) {

        .block-container {
            padding-left: 0.55rem;
            padding-right: 0.55rem;
            padding-top: 0.6rem;
        }

        h1 {
            font-size: 1.55rem !important;
        }

        h2 {
            font-size: 1.3rem !important;
        }

        .stButton > button {
            min-height: 78px;
            font-size: 2.15rem !important;
            border-radius: 20px;
        }

        .stButton > button[kind="primary"] {
            min-height: 58px;
            font-size: 0.95rem !important;
        }

        [data-testid="stMetricValue"] {
            font-size: 1.2rem;
        }

    }

    </style>
    """,
    unsafe_allow_html=True,
)


# ============================================================
# SESSION STATE
# ============================================================

if "auto_running" not in st.session_state:
    st.session_state.auto_running = False

if "arduino_control_mode" not in st.session_state:
    st.session_state.arduino_control_mode = None

if "tools_show_graph" not in st.session_state:
    st.session_state.tools_show_graph = False

if "tools_dataset" not in st.session_state:
    st.session_state.tools_dataset = None


# ============================================================
# UTILITY FUNCTIONS
# ============================================================

def get_csv_files():
    """Return all CSV files from the dataset directory."""

    return sorted(
        [
            filename
            for filename in os.listdir(DATA_DIR)
            if filename.lower().endswith(".csv")
        ]
    )


def read_sensors():
    """Read the three ultrasonic sensor distances."""

    try:

        raw_data = Bridge.call("distance")

        if isinstance(raw_data, str):
            distances = json.loads(raw_data)
        else:
            distances = raw_data

        distances = [
            float(value)
            for value in distances[:3]
        ]

        if len(distances) != 3:
            raise ValueError("Invalid sensor data.")

        return distances

    except Exception:
        return [0.0, 0.0, 0.0]


def send_command(action, speed=1000):
    """Send a movement command to the Arduino."""

    if action == "FORWARD":
        Bridge.call("moveForward", speed)

    elif action == "BACKWARD":
        Bridge.call("moveBackward", speed)

    elif action == "LEFT":
        Bridge.call("turnLeft", speed)

    elif action == "RIGHT":
        Bridge.call("turnRight", speed)

    elif action == "STOP":
        Bridge.call("stopMotors")


def set_control_mode(mode):
    """Set the control mode and watchdog configuration on Arduino."""

    Bridge.call(
        "setControlMode",
        mode
    )


def synchronize_control_mode(selected_mode):
    """
    Synchronize Streamlit mode with the Arduino.

    The robot is stopped whenever the control mode changes.
    """

    # Do nothing if the mode has not changed.
    if (
        st.session_state.arduino_control_mode
        == selected_mode
    ):
        return

    # Stop the robot before changing its control mode.
    try:
        Bridge.call("stopMotors")
    except Exception:
        pass

    try:
        set_control_mode(selected_mode)

        st.session_state.arduino_control_mode = (
            selected_mode
        )

    except Exception as error:

        st.error(
            f"Unable to change robot control mode: {error}"
        )


def record_data(filename, distances, action):
    """Save one sensor/action sample into a CSV dataset."""

    path = os.path.join(
        DATA_DIR,
        filename
    )

    new_row = pd.DataFrame(
        [{
        "timestamp": datetime.now().strftime(
            "%Y-%m-%d %H:%M"
            ),
            "distance_left": distances[0],
            "distance_center": distances[1],
            "distance_right": distances[2],
            "action": action
        }]
    )

    new_row.to_csv(
        path,
        mode="a",
        header=not os.path.exists(path),
        index=False
    )


def load_dataset(filename):
    """
    Load a dataset.

    Legacy French column names and action names are supported
    for compatibility with previously created datasets.
    """

    path = os.path.join(
        DATA_DIR,
        filename
    )

    df = pd.read_csv(path)

    # Legacy column names
    column_mapping = {
        "dist_gauche": "distance_left",
        "dist_centre": "distance_center",
        "dist_droite": "distance_right",
    }

    df = df.rename(
        columns=column_mapping
    )

    # Legacy action names
    action_mapping = {
        "AVANT": "FORWARD",
        "ARRIERE": "BACKWARD",
        "GAUCHE": "LEFT",
        "DROITE": "RIGHT",
        "STOP": "STOP",
    }

    if "action" in df.columns:

        df["action"] = (
            df["action"]
            .astype(str)
            .str.upper()
            .replace(action_mapping)
        )

    required_columns = [
        "distance_left",
        "distance_center",
        "distance_right",
        "action",
    ]

    missing_columns = [
        column
        for column in required_columns
        if column not in df.columns
    ]

    if missing_columns:

        raise ValueError(
            "Missing columns: "
            + ", ".join(missing_columns)
        )

    df = df.dropna(
        subset=required_columns
    )

    return df


# ============================================================
# KNN MODEL
# ============================================================

@st.cache_resource(show_spinner=False)
def train_knn_model(
    dataset_path,
    dataset_timestamp,
    k
):
    """Train and cache the KNN model."""

    df = pd.read_csv(
        dataset_path
    )

    # Legacy column names
    column_mapping = {
        "dist_gauche": "distance_left",
        "dist_centre": "distance_center",
        "dist_droite": "distance_right",
    }

    df = df.rename(
        columns=column_mapping
    )

    # Legacy action names
    action_mapping = {
        "AVANT": "FORWARD",
        "ARRIERE": "BACKWARD",
        "GAUCHE": "LEFT",
        "DROITE": "RIGHT",
        "STOP": "STOP",
    }

    df["action"] = (
        df["action"]
        .astype(str)
        .str.upper()
        .replace(action_mapping)
    )

    required_columns = [
        "distance_left",
        "distance_center",
        "distance_right",
        "action",
    ]

    df = df.dropna(
        subset=required_columns
    )

    if len(df) < 2:

        raise ValueError(
            "The dataset must contain at least 2 samples."
        )

    X = df[
        [
            "distance_left",
            "distance_center",
            "distance_right",
        ]
    ]

    y = df["action"]

    effective_k = min(
        k,
        len(df)
    )

    model = KNeighborsClassifier(
        n_neighbors=effective_k
    )

    model.fit(
        X,
        y
    )

    return model, df, effective_k


# ============================================================
# 3D DATASET VISUALIZATION
# ============================================================

def create_3d_dataset_plot(df):
    """
    Create the 3D KNN dataset visualization.

    X = left ultrasonic distance
    Y = center ultrasonic distance
    Z = right ultrasonic distance
    Color = movement action
    """

    fig = px.scatter_3d(
        df,
        x="distance_left",
        y="distance_center",
        z="distance_right",
        color="action",
        hover_data=[
            "distance_left",
            "distance_center",
            "distance_right",
            "action",
        ],
        labels={
            "distance_left": "Left distance",
            "distance_center": "Center distance",
            "distance_right": "Right distance",
            "action": "Action",
        },
        title="KNN Training Dataset"
    )

    for trace in fig.data:
        trace.marker.size = 5
        trace.marker.opacity = 0.7

    fig.update_layout(
        height=600,
        margin=dict(
            l=0,
            r=0,
            t=50,
            b=0
        ),
        scene=dict(
            xaxis_title="Left distance",
            yaxis_title="Center distance",
            zaxis_title="Right distance",
        )
    )

    return fig


# ============================================================
# MODE SELECTION
# ============================================================

mode = st.radio(
    "Operating mode",
    [
        "🎮 Manual Control",
        "📊 Dataset Collection",
        "🧠 Autonomous KNN",
        "🛠️ Tools",
    ],
    horizontal=True,
)


# ============================================================
# CONTROL MODE SYNCHRONIZATION
# ============================================================

control_mode_mapping = {
    "🎮 Manual Control": MANUAL_MODE,
    "📊 Dataset Collection": DATASET_MODE,
    "🧠 Autonomous KNN": AUTONOMOUS_MODE,

    # Tools is not a robot operating mode.
    # The Arduino stays in manual mode but the robot
    # is explicitly stopped when entering Tools.
    "🛠️ Tools": MANUAL_MODE,
}

selected_control_mode = control_mode_mapping[mode]

synchronize_control_mode(
    selected_control_mode
)


# Leaving autonomous mode
if (
    mode != "🧠 Autonomous KNN"
    and st.session_state.auto_running
):

    st.session_state.auto_running = False

    try:
        Bridge.call("stopMotors")
    except Exception:
        pass


# ============================================================
# WATCHDOG STATUS
# ============================================================

watchdog_value = WATCHDOG_VALUES[
    selected_control_mode
]

if mode == "🛠️ Tools":

    st.caption(
        "Safety watchdog: Disabled — Robot stopped"
    )

elif watchdog_value is None:

    st.caption(
        "Safety watchdog: Disabled"
    )

else:

    st.caption(
        f"Safety watchdog: {watchdog_value} ms"
    )


st.divider()


# ============================================================
# MOTOR SPEED
# ============================================================

speed = st.slider(
    "Motor speed",
    min_value=100,
    max_value=3000,
    value=1000,
    step=100,
)


# ============================================================
# SENSOR MONITORING
# ============================================================

if mode != "🛠️ Tools":

    distances = read_sensors()

    sensor_left, sensor_center, sensor_right = (
        st.columns(3)
    )

    with sensor_left:

        st.metric(
            "Left",
            f"{distances[0]:.0f}"
        )

    with sensor_center:

        st.metric(
            "Center",
            f"{distances[1]:.0f}"
        )

    with sensor_right:

        st.metric(
            "Right",
            f"{distances[2]:.0f}"
        )


# ============================================================
# MANUAL CONTROL
# ============================================================

if mode == "🎮 Manual Control":

    st.subheader(
        "Robot Control"
    )

    st.caption(
        "The robot keeps the last command until a new command is sent."
    )

    # Forward
    _, center, _ = st.columns(3)

    with center:

        if st.button(
            "⬆️",
            key="manual_forward",
            use_container_width=True
        ):

            send_command(
                "FORWARD",
                speed
            )

    # Left / Stop / Right
    left, center, right = st.columns(3)

    with left:

        if st.button(
            "⬅️",
            key="manual_left",
            use_container_width=True
        ):

            send_command(
                "LEFT",
                speed
            )

    with center:

        if st.button(
            "⏹️",
            key="manual_stop",
            use_container_width=True
        ):

            send_command(
                "STOP"
            )

    with right:

        if st.button(
            "➡️",
            key="manual_right",
            use_container_width=True
        ):

            send_command(
                "RIGHT",
                speed
            )

    # Backward
    _, center, _ = st.columns(3)

    with center:

        if st.button(
            "⬇️",
            key="manual_backward",
            use_container_width=True
        ):

            send_command(
                "BACKWARD",
                speed
            )


# ============================================================
# DATASET COLLECTION
# ============================================================

elif mode == "📊 Dataset Collection":

    st.subheader(
        "Dataset Collection"
    )

    st.caption(
        "The watchdog stops the robot if no new movement command "
        "is received for 400 ms."
    )

    files = get_csv_files()

    column_a, column_b = st.columns(2)

    with column_a:

        selected_file = st.selectbox(
            "Existing dataset",
            [
                "-- Create new dataset --"
            ] + files
        )

    with column_b:

        new_filename = st.text_input(
            "New dataset name",
            placeholder="example.csv"
        )

    active_filename = None

    if new_filename.strip():

        active_filename = (
            new_filename.strip()
        )

    elif selected_file != "-- Create new dataset --":

        active_filename = selected_file

    if (
        active_filename
        and not active_filename.lower().endswith(".csv")
    ):

        active_filename += ".csv"


    # Dataset information
    if active_filename:

        dataset_path = os.path.join(
            DATA_DIR,
            active_filename
        )

        if os.path.exists(dataset_path):

            try:

                current_df = load_dataset(
                    active_filename
                )

                st.success(
                    f"Recording dataset: {active_filename}"
                )

                stat1, stat2 = st.columns(2)

                with stat1:

                    st.metric(
                        "Samples",
                        len(current_df)
                    )

                with stat2:

                    st.metric(
                        "Movement classes",
                        current_df["action"].nunique()
                    )

            except Exception as error:

                st.error(
                    f"Unable to read dataset: {error}"
                )

        else:

            st.info(
                f"New dataset: {active_filename}"
            )

    else:

        st.warning(
            "Select an existing dataset or enter a new filename."
        )


    # --------------------------------------------------------
    # Robot control
    # --------------------------------------------------------

    st.subheader(
        "Robot Control"
    )

    def execute_and_record(action):
        """Send a movement command and record the sensor values."""

        send_command(
            action,
            speed
        )

        if active_filename:

            sensor_values = read_sensors()

            record_data(
                active_filename,
                sensor_values,
                action
            )

            st.toast(
                f"Recorded: {action}"
            )


    # Forward
    _, center, _ = st.columns(3)

    with center:

        if st.button(
            "⬆️",
            key="dataset_forward",
            use_container_width=True
        ):

            execute_and_record(
                "FORWARD"
            )


    # Left / Stop / Right
    left, center, right = st.columns(3)

    with left:

        if st.button(
            "⬅️",
            key="dataset_left",
            use_container_width=True
        ):

            execute_and_record(
                "LEFT"
            )

    with center:

        if st.button(
            "⏹️",
            key="dataset_stop",
            use_container_width=True
        ):

            send_command(
                "STOP"
            )

    with right:

        if st.button(
            "➡️",
            key="dataset_right",
            use_container_width=True
        ):

            execute_and_record(
                "RIGHT"
            )


    # Backward
    _, center, _ = st.columns(3)

    with center:

        if st.button(
            "⬇️",
            key="dataset_backward",
            use_container_width=True
        ):

            execute_and_record(
                "BACKWARD"
            )


# ============================================================
# AUTONOMOUS KNN
# ============================================================

elif mode == "🧠 Autonomous KNN":

    st.subheader(
        "Autonomous KNN"
    )

    st.caption(
        "The autonomous watchdog is set to 600 ms."
    )

    files = get_csv_files()

    if not files:

        st.error(
            "No dataset found. Create a dataset first."
        )

    else:

        dataset_file = st.selectbox(
            "Training dataset",
            files
        )

        dataset_path = os.path.join(
            DATA_DIR,
            dataset_file
        )

        try:

            dataset_timestamp = os.path.getmtime(
                dataset_path
            )

            dataset_df = load_dataset(
                dataset_file
            )

        except Exception as error:

            st.error(
                f"Unable to load dataset: {error}"
            )

            st.stop()


        st.metric(
            "Training samples",
            len(dataset_df)
        )


        # ----------------------------------------------------
        # K value
        # ----------------------------------------------------

        max_k = max(
            1,
            min(
                15,
                len(dataset_df)
            )
        )

        k_neighbors = st.slider(
            "Number of neighbors (K)",
            min_value=1,
            max_value=max_k,
            value=min(3, max_k),
            step=1
        )


        # ----------------------------------------------------
        # Start / Stop
        # ----------------------------------------------------

        start_col, stop_col = st.columns(2)

        with start_col:

            if (
                not st.session_state.auto_running
                and st.button(
                    "▶️ Start Autonomous Mode",
                    type="primary",
                    use_container_width=True
                )
            ):

                st.session_state.auto_running = True

                # Graph is not used during autonomous control.
                st.rerun()


        with stop_col:

            if (
                st.session_state.auto_running
                and st.button(
                    "⏹️ Stop Robot",
                    use_container_width=True
                )
            ):

                st.session_state.auto_running = False

                send_command(
                    "STOP"
                )

                st.rerun()


        # ----------------------------------------------------
        # Autonomous control fragment
        # ----------------------------------------------------

        run_every = (
            0.15
            if st.session_state.auto_running
            else None
        )


        @st.fragment(
            run_every=run_every,
            key="knn_control"
        )
        def autonomous_control():

            if not st.session_state.auto_running:
                return


            try:

                # Load cached KNN model
                knn, _, effective_k = train_knn_model(
                    dataset_path,
                    dataset_timestamp,
                    k_neighbors
                )


                # Read sensors
                current_distances = read_sensors()


                # KNN prediction
                prediction = knn.predict(
                    [current_distances]
                )[0]


                # Display current decision
                st.success(
                    f"Predicted action: {prediction}"
                )


                prediction_col, k_col = st.columns(2)

                with prediction_col:

                    st.metric(
                        "Current action",
                        prediction
                    )

                with k_col:

                    st.metric(
                        "K",
                        effective_k
                    )


                # Sensor values
                sensor_left, sensor_center, sensor_right = (
                    st.columns(3)
                )

                with sensor_left:

                    st.metric(
                        "Left",
                        f"{current_distances[0]:.1f}"
                    )

                with sensor_center:

                    st.metric(
                        "Center",
                        f"{current_distances[1]:.1f}"
                    )

                with sensor_right:

                    st.metric(
                        "Right",
                        f"{current_distances[2]:.1f}"
                    )


                # Send prediction to Arduino
                send_command(
                    prediction,
                    speed
                )


                # IMPORTANT:
                # No Plotly graph is generated here.
                # The fragment only performs the control loop.


            except Exception as error:

                st.session_state.auto_running = False

                try:
                    send_command("STOP")
                except Exception:
                    pass

                st.error(
                    f"Autonomous control error: {error}"
                )


        autonomous_control()


# ============================================================
# TOOLS
# ============================================================

elif mode == "🛠️ Tools":

    st.subheader(
        "Dataset Tools"
    )

    st.caption(
        "Analyze and download your KNN datasets."
    )

    files = get_csv_files()

    if not files:

        st.warning(
            "No CSV dataset is available."
        )

    else:

        tools_dataset = st.selectbox(
            "Select a dataset",
            files,
            key="tools_dataset_selector"
        )


        # Reset graph when selecting another dataset
        if (
            st.session_state.tools_dataset
            != tools_dataset
        ):

            st.session_state.tools_dataset = (
                tools_dataset
            )

            st.session_state.tools_show_graph = False


        dataset_path = os.path.join(
            DATA_DIR,
            tools_dataset
        )


        try:

            tools_df = load_dataset(
                tools_dataset
            )


            # ------------------------------------------------
            # Dataset information
            # ------------------------------------------------

            st.subheader(
                "Dataset Information"
            )

            info1, info2, info3 = st.columns(3)

            with info1:

                st.metric(
                    "Samples",
                    len(tools_df)
                )

            with info2:

                st.metric(
                    "Features",
                    3
                )

            with info3:

                st.metric(
                    "Classes",
                    tools_df["action"].nunique()
                )


            # ------------------------------------------------
            # Class distribution
            # ------------------------------------------------

            st.write(
                "Movement classes"
            )

            class_counts = (
                tools_df["action"]
                .value_counts()
            )

            st.dataframe(
                class_counts.rename("Samples"),
                use_container_width=True
            )


            # ------------------------------------------------
            # CSV download
            # ------------------------------------------------

            st.subheader(
                "Dataset Export"
            )

            with open(
                dataset_path,
                "rb"
            ) as file:

                st.download_button(
                    label="📥 Download CSV",
                    data=file,
                    file_name=tools_dataset,
                    mime="text/csv",
                    use_container_width=True
                )


            # ------------------------------------------------
            # 3D graph
            # ------------------------------------------------

            st.subheader(
                "3D Dataset Visualization"
            )

            graph_label = (
                "✖ Hide Graph"
                if st.session_state.tools_show_graph
                else "📈 Visualize 3D Graph"
            )

            if st.button(
                graph_label,
                use_container_width=True,
                key="tools_graph_button"
            ):

                st.session_state.tools_show_graph = (
                    not st.session_state.tools_show_graph
                )

                st.rerun()


            # IMPORTANT:
            # The graph is created only after the user
            # explicitly requests it.

            if st.session_state.tools_show_graph:

                st.plotly_chart(
                    create_3d_dataset_plot(
                        tools_df
                    ),
                    use_container_width=True
                )


            # ------------------------------------------------
            # Raw dataset preview
            # ------------------------------------------------

            with st.expander(
                "View raw dataset"
            ):

                st.dataframe(
                    tools_df,
                    use_container_width=True,
                    hide_index=True
                )


        except Exception as error:

            st.error(
                f"Unable to process dataset: {error}"
            )


# ============================================================
# APPLICATION
# ============================================================

App.run()